const mongoose = require('mongoose');
const express = require('express');
const cors = require('cors');

const port = process.env.PORT || 5000;
const app = express();

app.use(express.json());
app.use(cors({ origin: 'http://localhost:3000' }));

// Connect MongoDB
mongoose.connect('mongodb://localhost:27017/YellowManga')
    .then(() => console.log("Database connected"))
    .catch(() => console.log("Database connection failed"));

// Schemas
const UserSchema = new mongoose.Schema({
    fname: String,
    lname: String,
    email: { type: String, required: true },
    password: { type: String, required: true }
});

const addressSchema = new mongoose.Schema({
    fname: String,
    lname: { type: String, required: true },
    address: { type: String, required: true },
    address2: String,
    city: { type: String, required: true },
    state: { type: String, required: true },
    zipCode: { type: Number, required: true },
    country: { type: String, required: true }
});

const cardSchema = new mongoose.Schema({
    name: String,
    cardNumber: { type: String, required: true },
    cvv: { type: Number, required: true },
    expirationDate: { type: String, required: true }
});

const productSchema = new mongoose.Schema({
    title: { type: String, required: true },
    description: String,
    price: { type: Number, required: true },
    image: String,
    category: String
});

const orderSchema = new mongoose.Schema({
    items: [{
        title: { type: String, required: true },
        price: { type: Number, required: true },
        qty: { type: Number, required: true }
    }],
    totalPrice: { type: Number, required: true },
    address: addressSchema,
    payment: {
        name: String,
        cardNumber: String,
        expirationDate: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Models
const User = mongoose.model('users', UserSchema);
const Address = mongoose.model('adressDetails', addressSchema);
const Payment = mongoose.model('payments', cardSchema);
const Product = mongoose.model('products', productSchema);
const Order = mongoose.model('orders', orderSchema);

// Routes
app.post('/posting', async (req, res) => {
    try {
        const user = new User(req.body);
        const result = await user.save();
        res.send(result);
    } catch (e) {
        console.error(e);
        res.status(400).send({ message: 'User creation failed', error: e.message });
    }
});

app.post('/address', async (req, res) => {
    try {
        const address = new Address(req.body);
        const result = await address.save();
        res.send(result);
    } catch (e) {
        console.error(e);
        res.status(400).send({ message: 'Address save failed', error: e.message });
    }
});

app.get('/users', async (req, res) => {
    try {
        const users = await User.find();
        res.send(users);
    } catch (error) {
        res.status(500).send({ message: 'Failed to fetch users', error });
    }
});

app.post('/add-product', async (req, res) => {
    try {
        const product = new Product(req.body);
        const saved = await product.save();
        res.status(201).json(saved);
    } catch (err) {
        res.status(400).json({ message: 'Error adding product', error: err.message });
    }
});

app.get('/products', async (req, res) => {
    try {
        const allProducts = await Product.find();
        res.send(allProducts);
    } catch (err) {
        res.status(500).send({ message: 'Error fetching products', error: err.message });
    }
});

app.post('/submit-order', async (req, res) => {
    try {
        const { items, totalPrice, address, payment } = req.body;

        if (!Array.isArray(items) || items.length === 0) {
            return res.status(400).send({ message: 'Order must contain at least one item' });
        }

        for (let i = 0; i < items.length; i++) {
            const { title, price, qty } = items[i];
            if (!title || !price || !qty) {
                return res.status(400).send({ message: `Missing fields in item ${i + 1}` });
            }
        }

        const newOrder = new Order({ items, totalPrice, address, payment });
        const savedOrder = await newOrder.save();
        res.status(201).json(savedOrder);
    } catch (err) {
        console.error('Order submission error:', err);
        res.status(500).json({ message: 'Error submitting order', error: err.message });
    }
});

app.get('/admin/orders', async (req, res) => {
    try {
        const orders = await Order.find();
        res.send(orders);
    } catch (err) {
        res.status(500).send({ message: 'Error fetching orders', error: err.message });
    }
});

app.post('/cardetails', async (req, res) => {
    try {
        const card = new Payment(req.body);
        const saved = await card.save();
        res.send(saved);
    } catch (e) {
        console.error(e);
        res.status(400).send({ message: 'Card details save failed', error: e.message });
    }
});

app.get('/datas', async (req, res) => {
    try {
        const cards = await Payment.find({}, 'name cardNumber expirationDate');
        res.send(cards);
    } catch (e) {
        console.error(e);
        res.status(500).send('Failed to retrieve card data');
    }
});

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email, password });
        if (user) {
            res.status(200).json({ success: true, message: 'Login successful' });
        } else {
            res.status(401).json({ success: false, message: 'Invalid email or password' });
        }
    } catch (error) {
        console.error('Error during login:', error);
        res.status(500).json({ success: false, message: 'An error occurred. Please try again later.' });
    }
});

app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
